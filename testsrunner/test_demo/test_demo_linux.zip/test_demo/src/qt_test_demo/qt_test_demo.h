#include <QtTest/QtTest>

class QtTestDemo: public QObject
{
    Q_OBJECT
private slots:
    void testShouldPass();
    void testShouldFail();
    void testShouldFail2();
    void testShouldWarn();
    void testExpectedFail();

private:
    void delay();
};

