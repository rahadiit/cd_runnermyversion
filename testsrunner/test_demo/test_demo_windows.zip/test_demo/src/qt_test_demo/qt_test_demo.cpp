#include "qt_test_demo.h"


void QtTestDemo::testShouldPass()
{
    QCOMPARE(1, 1);
}


void QtTestDemo::testShouldFail()
{
    QCOMPARE(1, 0);
}


void QtTestDemo::testShouldFail2()
{
    QFAIL("This is a cutom fail!");
}



void QtTestDemo::testShouldWarn()
{
    QWARN("This is a custom warning!");
}


void QtTestDemo::testExpectedFail()
{
    QEXPECT_FAIL("", "Will be fixed in the next release!", Continue);
    QCOMPARE(1, 0);
}


void QtTestDemo::delay()
{
}


QTEST_MAIN(QtTestDemo)
