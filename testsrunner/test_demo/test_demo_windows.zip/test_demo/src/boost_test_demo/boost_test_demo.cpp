#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MAIN
#define BOOST_TEST_MODULE TestBoostDemo
#include <boost/test/unit_test.hpp>
#include <iostream>


// This is used to turn off std::cout buffering. It makes tests running progress show more accurate.
static struct DisableStdCoutBuffering
{
	DisableStdCoutBuffering()
	{
			std::cout.setf(std::ios_base::unitbuf);
	}
} s_disableStdCoutBuffering;


BOOST_AUTO_TEST_CASE( testShouldPass )
{
	// Delay
	for (int i = 0, j=1; i <100000000; ++i) { j++; j--; }
	BOOST_REQUIRE( true );
}

BOOST_AUTO_TEST_CASE( testShouldWarnAndFail )
{
	BOOST_WARN( 0 );
	BOOST_REQUIRE( 0 );
}

BOOST_AUTO_TEST_SUITE( MainTestSuite )

BOOST_AUTO_TEST_CASE( testInTestSuiteShouldWarnAndFail )
{
	// Delay
	int j = 1;
	for (int i = 0 ; i <100000000; ++i) { j++; j--; }

	BOOST_WARN( j!=0 );
	BOOST_CHECK( j!=0 );
}

BOOST_AUTO_TEST_CASE( testInTestSuiteShouldFail )
{
	BOOST_REQUIRE_MESSAGE( 0, "This assertion will always fail!" );
}

BOOST_AUTO_TEST_CASE( testInTestSuiteShouldPass )
{
	// Delay
	for (int i = 0, j=1; i <100000000; ++i) { j++; j--; }
	BOOST_REQUIRE( 1 );
}

BOOST_AUTO_TEST_SUITE_END()

BOOST_AUTO_TEST_SUITE( AdditionalTestSuite )

BOOST_AUTO_TEST_CASE( testWithoutCheckAssertions )
{
}

BOOST_AUTO_TEST_CASE( test_againWithoutAssertions )
{
	// Delay
	for (int i = 0, j=1; i <100000000; ++i) { j++; j--; }
}

BOOST_AUTO_TEST_SUITE( AnotherTestSuite )

BOOST_AUTO_TEST_CASE( testCaseInAnotherTestSuite )
{
	BOOST_REQUIRE_MESSAGE( true, "This is multi-line message.\nThis is the second part of the message." );
}

BOOST_AUTO_TEST_SUITE_END()

BOOST_AUTO_TEST_SUITE_END()
